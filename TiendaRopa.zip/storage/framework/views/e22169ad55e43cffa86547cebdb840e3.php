
<?php $__env->startSection('title', 'HOME'); ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <?php if(session('success')): ?>
    <div class="alert alert-success text-center" style="font-size: 17px;">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
</div>

<!-- Formulario de búsqueda -->
<div class="container mb-4">
    <form action="<?php echo e(route('productos.buscar')); ?>" method="GET" class="mb-4">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar">
            <button type="submit" class="btn btn-secondary">Buscar</button>
        </div>
    </form>
</div>

<!-- Tarjetas de productos -->
<div class="container">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-4 g-4">
        <?php $__currentLoopData = $ropas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ropa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
            <div class="card">
                <div class="contimagencard">
                    <img src="<?php echo e(asset($ropa->image)); ?>" class="card-img-top imagencard" alt="Imagen de la ropa" />
                </div>
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($ropa->name); ?></h4>
                    <p><?php echo e($ropa->description); ?></p>
                    <p class="card-text"><strong>Precio: </strong> <u>$<?php echo e($ropa->price); ?></u></p>
                    <p class="btn-holder">
                        <a href="<?php echo e(route('aniadirropa.to.cart', $ropa->id)); ?>" class="btn btn-outline-danger">Añadir al
                            carrito</a>

                        <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('ropa.favoritos.toggle', $ropa->id)); ?>" method="POST"
                        style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php if(auth()->user()->ropas && auth()->user()->ropas->wherePivot('ropa_id', $ropa->id)->count() >
                        0): ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-outline-warning">Quitar de favoritos</button>
                        <?php else: ?>
                        <button type="submit" class="btn btn-outline-success">FAVORITOS</button>
                        <?php endif; ?>
                    </form>
                    <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVEL\TiendaRopa\resources\views/productos.blade.php ENDPATH**/ ?>