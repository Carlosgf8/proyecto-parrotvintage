
<?php $__env->startSection('title', 'Recibo de Compra'); ?>
<?php $__env->startSection('content'); ?>
<head>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<div class="container">
    <h1>Recibo de Compra</h1>
    <?php if(auth()->guard()->check()): ?>
    <p>Usuario: <i class="fas fa-user"></i> <?php echo e(auth()->user()->name); ?></p>
    <?php endif; ?>

    <table class="table">
    <thead>
            <tr>
                <th>#</th>
                <th>Producto</th>
                <th>Precio Unitario</th>
                <th>Cantidad</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0; $totalQuantity = 0; ?>
            <?php if(session('cart')): ?>
                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $subtotal = $details['price'] * $details['quantity']; 
                    $total += $subtotal;
                    $totalQuantity += $details['quantity'];
                    ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($details['name']); ?></td>
                        <td>$<?php echo e($details['price']); ?></td>
                        <td><?php echo e($details['quantity']); ?></td>
                        <td>$<?php echo e(number_format($subtotal, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No hay productos en el carrito.</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" class="text-right fw-bold">Total:</td>
                <td class="fw-bold"><?php echo e($totalQuantity); ?></td>
                <td colspan="1" class="text-right fw-bold">$<?php echo e(number_format($total, 2)); ?></td>
            </tr>
            <tr>
                <td colspan="5">
                    <form method="POST" action="<?php echo e(route('guardar.pedido')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary">Pagar</button>
                    </form>
                </td>
            </tr>
        </tfoot>
    </table>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVEL\TiendaRopa\resources\views/recibo.blade.php ENDPATH**/ ?>