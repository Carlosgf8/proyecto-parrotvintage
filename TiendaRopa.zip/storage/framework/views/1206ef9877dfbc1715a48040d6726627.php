<!DOCTYPE html>
<html lang="en">

<head>
    <title>Registro de Pedidos</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Kanit&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Kanit', sans-serif;
        }
    </style>
</head>

<body>
    <!-- Botón para volver -->
    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary position-fixed top-0 start-0 m-3">Volver al Home</a>
    

    <div class="container my-5">
       

        <h1 class="text-center mb-4">Registro de Pedidos</h1>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre Usuario</th>
                    <th>Precio</th>
                    <th>Cantidad de Artículos</th>
                    <th>Fecha del Pedido</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pedido->id); ?></td>
                    <td><?php echo e($pedido->nombre_usuario); ?></td>
                    <td><?php echo e($pedido->precio); ?></td>
                    <td><?php echo e($pedido->cantidad_articulos); ?></td>
                    <td><?php echo e($pedido->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH D:\xampp\htdocs\LARAVEL\TiendaRopa\resources\views/admin/verpedidos.blade.php ENDPATH**/ ?>