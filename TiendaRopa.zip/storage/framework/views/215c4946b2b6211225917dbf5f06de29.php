<!DOCTYPE html>
<html lang="en">

<head>
    <title>Panel de Administración - Mostrar y Modificar Producto</title>
    <!-- Encabezado, estilos, etc. -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Kanit&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Kanit', sans-serif;
        }
    </style>
</head>

<body>
    <!-- Contenido -->
    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary position-fixed top-0 start-0 m-3">Volver al Home</a>
    <a href="<?php echo e(route('ver.registro.pedidos')); ?>" class="btn btn-primary position-fixed top-3 start-0 m-3">Ver registro de pedidos</a>
    <div class="container my-5">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <h1 class="text-center mb-4">Mostrar y Modificar Producto</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ropas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ropa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ropa->id); ?></td>
                    <td><?php echo e($ropa->name); ?></td>
                    <td><?php echo e($ropa->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('editar.ropa', $ropa->id)); ?>" class="btn btn-primary">Editar</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH D:\xampp\htdocs\LARAVEL\TiendaRopa\resources\views/admin/mostrarmodificar.blade.php ENDPATH**/ ?>