

<?php $__env->startSection('title', 'Pedidos'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Listado de Pedidos</h1>

        <?php if($pedidos->isEmpty()): ?>
        <p class="lead text-center">No tienes pedidos asignados a este usuario</p>
        <?php else: ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre Usuario</th>
                        <th>Precio</th>
                        <th>Cantidad de Artículos</th>
                        <th>Fecha del Pedido</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pedido->id); ?></td>
                        <td><?php echo e($pedido->nombre_usuario); ?></td>
                        <td><?php echo e($pedido->precio); ?></td>
                        <td><?php echo e($pedido->cantidad_articulos); ?></td>
                        <td><?php echo e($pedido->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVEL\TiendaRopa\resources\views/registropedidos.blade.php ENDPATH**/ ?>