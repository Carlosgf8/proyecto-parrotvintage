

<?php $__env->startSection('title', 'Favoritos'); ?>

<?php $__env->startSection('content'); ?>
<head>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h2 class="mb-0">Tus productos favoritos</h2>
        </div>
        <div class="card-body">
            <?php if(count($favoritos) > 0): ?>
            <ul class="list-group">
                <?php $__currentLoopData = $favoritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-0"><?php echo e($favorito->name); ?> - <?php echo e($favorito->description); ?></h5>
                        </div>
                        <div>
                            <span class="badge bg-primary">$<?php echo e($favorito->price); ?></span>
                        </div>
                        <div>
                            <img src="<?php echo e(asset($favorito->image)); ?>" alt="Imagen del producto" class="img-fluid"
                                style="max-width: 100px; max-height: 100px;">
                        </div>
                        <div>
                            <form action="<?php echo e(route('ropa.carrito.aniadir', $favorito->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-success">Añadir al carrito</button>
                            </form>
                        </div>
                        <div>
                            <form action="<?php echo e(route('ropa.favoritos.eliminar', $favorito->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger">Eliminar de favoritos</button>
                            </form>
                        </div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
            <p class="lead text-center">No tienes productos favoritos.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVEL\TiendaRopa\resources\views/favoritos.blade.php ENDPATH**/ ?>