
<?php $__env->startSection('title', 'HOME'); ?>
<?php $__env->startSection('content'); ?>

<head>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<div class="table-container">
<?php if(!session('cart') || count(session('cart')) === 0): ?>
    <h1 class="text-center">No hay productos en el carrito.</h1>
    <?php else: ?>
    <table id="cart" class="table table-bordered table-striped tabla">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Producto</th>
                <th scope="col">Precio</th>
                <th scope="col">Cantidad</th>
                <th scope="col">Subtotal</th>
                <th scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0 ?>
            <?php if(session('cart')): ?>
            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $subtotal = $details['price'] * $details['quantity']; 
            $total += $subtotal;
            ?>
            <tr rowId="<?php echo e($id); ?>">
                <td><?php echo e($loop->iteration); ?></td>
                <td data-th="Product">
                    <div class="row">
                        <div class="col-3 col-sm-3 hidden-xs"><img src="<?php echo e($details['image']); ?>" class="card-img-top" />
                        </div>
                        <div class="col-9 col-sm-9">
                            <h4 class="nomargin"><?php echo e($details['name']); ?></h4>
                        </div>
                    </div>
                </td>
                <td data-th="Price">$<?php echo e($details['price']); ?></td>
                <td data-th="Quantity"> 
                    <input type="number" class="form-control edit-cart-info" value="<?php echo e($details['quantity']); ?>" />
                </td>
                <td data-th="Subtotal" class="text-center">$<?php echo e(number_format($subtotal, 2)); ?></td>
                <td class="actions">
                    <a class="btn btn-outline-danger btn-sm delete-product"><i class="fa fa-trash-o">Eliminar</i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4" class="text-right fw-bold">Total:</td>
                <td class="text-center fw-bold">$<?php echo e(number_format($total, 2)); ?></td>
                <td class="actions">
                    <a href="<?php echo e(url('/productos')); ?>" class="btn btn-secondary"><i class="fa fa-angle-left"></i>
                       CONTINUAR CON LA COMPRA</a>
                       <button class="btn btn-danger" onclick="location.href='<?php echo e(route('recibo.compra')); ?>'">REALIZAR COMPRA</button>
                </td>
            </tr>
        </tfoot>
    </table>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    $(".edit-cart-info").change(function (e) {
        e.preventDefault();
        var ele = $(this);
        $.ajax({
            url: '<?php echo e(route('update.sopping.cart')); ?>',
            method: "patch",
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                id: ele.parents("tr").attr("rowId"),
                quantity: ele.val(),
            },
            success: function (response) {

            }
        });
    });

    $(".delete-product").click(function (e) {
        e.preventDefault();
        var ele = $(this);

        if (confirm("De verdad quieres eliminar este producto de tu carrito?")) {
            $.ajax({
                url: '<?php echo e(route('delete.cart.product')); ?>',
                method: "DELETE",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: ele.parents("tr").attr("rowId")
                },
                success: function (response) {
                    window.location.reload();
                }
            });
        }
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVEL\TiendaRopa\resources\views/cart.blade.php ENDPATH**/ ?>